import { useEffect, useState } from "react";
import "../../index.css";
function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="logo" style={{ color: "#fff" }}>whistle<span style={{ color: "var(--purple)" }}>.</span></div>
            <p style={{ marginTop: 10, fontSize: 13, maxWidth: 320 }}>Doctor-led invisible aligners delivered to your door.</p>
          </div>
          <div>
            <h4>Quick links</h4>
            <ul><li><a href="#">Home</a></li><li><a href="#">Book a Scan</a></li><li><a href="#">How it Works</a></li><li><a href="#">FAQs</a></li></ul>
          </div>
          <div>
            <h4>Get in touch</h4>
            <ul><li>+91 00000 00000</li><li>hello@whistle.in</li></ul>
          </div>
          <div>
            <h4>Follow us</h4>
            <ul><li><a href="#">Instagram</a></li><li><a href="#">Facebook</a></li><li><a href="#">YouTube</a></li></ul>
          </div>
        </div>
        <div className="footer-bottom">© {new Date().getFullYear()} Whistle. All rights reserved.</div>
      </div>
    </footer>
  );
}

export default Footer;